<h3 id="glossary">Site Inventory</h3>
  <ul>
    <li class="sidebar"><a href="#published">Published Subclasses</a></li>
    <li class="sidebar"><a href="drafts.html">Draft Subclasses</a></li>
    <li class="sidebar"><a href="spells.html">Spell Book</a></li>
    <li class="sidebar"><a href="#races">Races</a></li>
    <li class="sidebar"><a href="feats.html">Feats</a></li>
    <li class="sidebar"><a href="invocations.html">Warlock Invocations</a></li>
  </ul>