<h3>Warlock</h3>
  <ul>
    <li>
      <a href="eots-holy-flame.html">Holy Flame</a> <p class="book eots">(EotS)</p>
      <p class="short-desc">
        You were selected by The High Council of the Holy Flame to archive; the history of the Holy Flame. When required you can use your knowledge to aid your allies or hinder your enemies.
      </p>
    </li>
    <li>
      <a href="sofw-slaad-lord.html">Slaad Lord</a> <p class="book sofw">(SoFW)</p>
      <p class="short-desc">
        You have made a pact with a Slaad Lord from the plane of Limbo, a being of pure chaos. They are the closest thing that the Slaadi have to actual deities, but they do not command any worship. 
      </p>
    </li>
  </ul>