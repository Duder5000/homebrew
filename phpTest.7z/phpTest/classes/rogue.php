<h3>Rogue</h3>
<ul>
  <li>
    <a href="sofw-master-thrower.html">Master Thrower</a> <p class="book sofw">(SoFW)</p>
    <p class="short-desc">
      You have honed your skills to become a master all thrown weapons. You spent your years before adventuring learning pub tricks to con other patrons out of gold, were raised by the circus, or any other experiences that honed your skills. 
    </p>
  </li>
</ul>