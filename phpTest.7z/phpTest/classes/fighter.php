<h3>Fighter</h3>
<ul>
  <li>
    <a href="sofw-arcane-archer-redux.html">Arcane Archer Redux</a> <p class="book sofw">(SoFW)</p>
    <p class="short-desc">
     A revised version of the Arcane Archer Martial Archetype.</br>
     An Arcane Archer studies a unique elven method of archery that weaves magic into attacks to produce supernatural effects.
    </p>
  </li>
</ul>