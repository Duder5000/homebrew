<h3>Ranger</h3>
  <ul>
    <li><a href="ranger-spells.html">Ranger Revised (Known Spells)</a> <p class="book sofw">(SoFW)</p></li>
    <p class="short-desc">
      Additional spell for the Beast Master and Hunter Ranger Subclasses when you reach certain levels in the class.
    </p>
  </ul>