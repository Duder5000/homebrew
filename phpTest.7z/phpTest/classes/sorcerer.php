<h3>Sorcerer</h3>
<ul>
  <li>
    <a href="eots-plagueblessed.html">Plagueblessed</a> <p class="book eots">(EotS)</p>
    <p class="short-desc">
      You were born of two that bare the mark of the Spellplague, the Spellplague is part of your blood. You were trained from birth under the watchful eye of the High Council to be their enforcer. 
    </p>
  </li>
  <li>
    <a href="aofl-gem-draconic.html">Gem Draconic Bloodline</a> <p class="book odvaskar">(AoFL+)</p>
    <p class="short-desc">
      An addition to the Draconic Bloodline Sorcerer, adding Gem Dragon options. 
    </p>
  </li>
</ul>