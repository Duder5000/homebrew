<div class="w3-col l4 img-card">
      <a href="index.html"><img src="img/duder-logo.png" class="side-img"></a>
</div>