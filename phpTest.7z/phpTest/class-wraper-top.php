<div class="w3-row">

<div class="w3-col l8 s12">
  <div class="w3-card-4 w3-margin card">
    <div id="published" class="w3-container">
      <h2>
        <b>Published Subclasses</b>
      </h2>