<h3 class="inline-h">            
  <a href="feats.html#arcane-shot-adept">Arcane Shot Adept</a> 
</h3>
<p class="book sofw">(SoFW)</p>

<ul>
  <li>
    <p class="short-desc">
      You have training to unleash special magical effects with shortbow and longbow attacks.
    </p>
  </li>
</ul>