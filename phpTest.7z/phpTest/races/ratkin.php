<h3 class="inline-h">            
  <a href="https://www.dndbeyond.com/races/742585-ratkin" target="_blank">Ratkin</a>
</h3>
<p class="book kryat">(Kryat)</p>

<ul>
  <li>
    <p class="short-desc">
      Ratkin are the dominant race of the Underdark or at least that is what they believe. Ratkin communities often inhabit caverns a short distance from Drow or Gnome cites.
    </p>
  </li>
</ul>