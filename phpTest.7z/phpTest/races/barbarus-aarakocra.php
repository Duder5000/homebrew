<h3 class="inline-h">            
  <a href="https://www.dndbeyond.com/races/742629-barbarus-aarakocra" target="_blank">Barbarus Aarakocra</a> 
</h3>
<p class="book kryat">(Kryat)</p>

<ul>
  <li>
    <p class="short-desc">
      Aarakocra from the moon of Barbarus have evolved to breath dense air of Barbarus, as such they require special accommodation to breath on Terra or any of the other moons.
    </p>
  </li>
</ul>