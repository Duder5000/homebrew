<h3 class="inline-h">            
  <a href="https://www.dndbeyond.com/races/743174-chiroptera" target="_blank">Chiroptera</a>
</h3>
<p class="book kryat">(Kryat)</p>

<ul>
  <li>
    <p class="short-desc">
      Chiroptera are a bat-like race that evolved on the moon of Barbarus. The Chiroptera were the first sentient race to evolve on Barbarus.
    </p>
  </li>
</ul>