<div class="w3-col l4">      
  <div class="w3-card w3-margin-left w3-margin-top">
    <div class="w3-container card">