<div class="w3-card-4 w3-margin card">
  <div id="races" class="w3-container">
    <h2>
      <b>Races</b>
      <!-- <a href=""><img class="link-icon" src="img/icons/races.png"></a> -->
      <img class="misc-icon" src="img/icons/races.png">
    </h2>