<h3 id="key">Key</h3>
  <ul>
    <li class="sidebar">
      <p class="sofw sidebar">SoFW</p> <p class="sidebar">= The Scrolls of Forgotten Warriors</p>
    </li>
    <li class="sidebar">
      <p class="eots sidebar">EotS</p> <p class="sidebar">= Echos of the Spellplague</p>
    </li>
    <li class="sidebar">
      <p class="odvaskar sidebar">AoFL+</p> <p class="sidebar">= Addition to Archive of Forgotten Lore by <a href="https://www.patreon.com/Odvaskar" target="_blank">Odvaskar</a></p>
    </li>
    <li class="sidebar">
      <p class="kryat sidebar">Kryat</p> <p class="sidebar">= Kryat (Homebrew Setting)</p>
    </li>
  </ul>