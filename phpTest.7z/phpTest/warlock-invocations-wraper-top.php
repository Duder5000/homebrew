<div class="w3-card-4 w3-margin card">
  <div id="invocations" class="w3-container">
    <h2><b>Warlock Invocations</b> <a href="invocations.html"><img class="link-icon" src="img/icons/warlock-eye.svg"></a></h2>