<div class="w3-card-4 w3-margin card">
  <div id="spells" class="w3-container">
    <h2><b>Spell Book</b> <a href="spells.html"><img class="link-icon" src="img/icons/spellbook.png"></a></h2>