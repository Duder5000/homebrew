<h3 class="inline-h">            
  <a href="spells.html#spellscar-blade">Spellscar Blade</a>
  <img class="spell-icon" src="img/icons/evocation.png"> <p class="spell-level">1st</p>
</h3>
<p class="book eots">(EotS)</p>

<ul>
  <li>
    <p class="short-desc">
      You draw forth the energy of your Spellscar to form a sword of blue fire in your hand. This magic sword lasts until the spell ends. It counts as a simple melee weapon with which you are proficient. It deals 1d8 fire damage on a hit and has the <em>finesse</em> and <em>light</em> properties. 
      Additionally, when you attack a creature that has already taken fire damage this round, you have advantage on the attack (maximum of once per turn).
    </p>
  </li>
</ul>