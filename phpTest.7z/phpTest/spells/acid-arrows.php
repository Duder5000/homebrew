<h3 class="inline-h">            
  <a href="spells.html#acid-arrows">Acid Arrows</a>
  <img class="spell-icon" src="img/icons/transmutation.png"> <p class="spell-level">2nd</p>
</h3>
<p class="book sofw">(SoFW)</p>

<ul>
  <li>
    <p class="short-desc">
      You touch a quiver containing arrows or bolts. When a target is hit by an attack using a piece of ammunition drawn from the quiver, the target takes an extra 1d4 acid damage. The spell’s magic ends on the piece of ammunition when it hits or misses.
    </p>
  </li>
</ul> 