<div class="w3-card-4 w3-margin card">
  <div id="feats" class="w3-container">
    <h2><b>Feats</b> <a href="feats.html"><img class="link-icon" src="img/icons/anvil.png"></a></h2>